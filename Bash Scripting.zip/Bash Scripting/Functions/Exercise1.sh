read FPATH
function countFile()	{
	local COUNT=$(find ${FPATH} -type f | wc -l)
	echo "$COUNT"
}
countFile