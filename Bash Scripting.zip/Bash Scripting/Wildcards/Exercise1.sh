#!/bin/bash
for FILE in *.png
do
	mv "$FILE" "`date "+%Y-%m-%d"`-${FILE}"
done
