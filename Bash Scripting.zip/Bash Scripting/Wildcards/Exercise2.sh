#!/bin/bash
read -p "Enter file extension: " FEX
read -p "Enter File Prefix to be added: " FPREF
if [[ -z "$FEX" ]]
then
	for FILE in *.$FEX
	do
		mv -f "$FILE" "`date "+%Y-%m-%d"`-${FILE}"
		echo $FILE
		echo "`date "+%Y-%m-%d"`-${FILE}"
	done
else
	for FILE in *.$FEX
	do
		mv "$FILE" "${FPREF}-${FILE}"
		echo $FILE
		echo "$FILE" "${FPREF}-${FILE}"
	done
fi

