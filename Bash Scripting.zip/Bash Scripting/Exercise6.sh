#!/bin/bash
read -p "Enter file name/ directory: " entry
if [ -d "$entry" ] 
then
	echo "${entry} is a directory"
	ls -l "~${entry}"
elif [ -f "$entry" ]
then
	echo "${entry} is a file"
	ls -l "${entry}"
else
	echo "${entry} is neither a file nor a directory"
fi