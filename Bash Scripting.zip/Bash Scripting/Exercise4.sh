#!/bin/bash
FILE="/etc/shadow"
if [ -f $FILE ]
	then
		echo "Shadow passwords are enabled."
		if [-w $FILE]
			then
				echo "You have permissions to edit /etc/shadow."
		else
			echo "You do NOT have permissions to edit /etc/shadow."
		fi
	else
		echo "404"
fi

		