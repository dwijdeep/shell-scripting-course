STATUS=$?
ping amazon.in

if [ "$STATUS" -eq "0" ]
then
	echo "This script will exit with a 0 exit status."
else
	echo "Status is not 0"
fi
