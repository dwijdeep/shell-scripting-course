read File
if [ -f "$File" ]
then	
	exit 0
elif [ -d "$File" ]
then
	exit 1
else
	exit 2
fi


