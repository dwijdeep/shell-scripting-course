#!/bin/bash
ARRAY=("man" "bear" "pig" "dog" "cat" "sheep")
for item in ${ARRAY[@]};
do
	echo $item
done
