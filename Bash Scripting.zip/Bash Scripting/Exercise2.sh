#!/bin/bash
VARIABLE="Shell Scripting is Fun!"
echo $VARIABLE