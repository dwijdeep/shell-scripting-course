#!/bin/bash
#HOSTNAME=`hostname`
echo "This script is running on $HOSTNAME."