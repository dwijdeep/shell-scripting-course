#!/bin/bash
echo "Shell Scripting is Fun!"
#use chmod +x fname cmd ti run this