cd ../../
cd Desktop/Shebang

mkdir Deep